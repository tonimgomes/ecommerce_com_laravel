
<?php $__env->startSection("conteudo"); ?>
    <?php echo $__env->make("produtos", ['lista' => $lista], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anton\ecommerce\resources\views/home.blade.php ENDPATH**/ ?>