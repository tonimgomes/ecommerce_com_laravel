<?php

namespace App\Models;


class itensPedido extends RModel
{
  
}
