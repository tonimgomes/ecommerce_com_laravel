<?php

namespace App\Models;

class endereco extends RModel
{

}
