<?php

namespace App\Models;


class produto extends RModel
{
    protected $table = "produtos";
    protected $fillable = ['nome','foto','descricao','valor','categoria_id'];
}
