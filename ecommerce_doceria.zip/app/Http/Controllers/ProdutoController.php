<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\produto;

class ProdutoController extends Controller
{
    public function index(Request $request){
        $data = [];
        

        //Buscando os produtos do Banco
        $listaProdutos = produto::all();
        $data["lista"] = $listaProdutos;

        return view("home", $data);
    }

    public function cadastrar(Request $request){
        $data = [];
        return view("cadastrar", $data);
    }

    public function adicionarCarrinho($idProduto = 0, Request $request){
       $prod = produto::find($idProduto);
       
       if($prod){
        $carrinho = session('cart', []);

        array_push($carrinho, $prod);

        session(['cart' => $carrinho]);
       }

       return redirect()->route("home");
    }

    public function verCarrinho(Request $request){
        $carrinho = session('cart', []);
        $data = ['cart' => $carrinho];

        return view("carrinho", $data);
    }
}
