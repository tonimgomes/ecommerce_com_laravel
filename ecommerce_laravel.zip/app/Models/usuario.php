<?php

namespace App\Models;


class usuario extends RModel
{
    
}
