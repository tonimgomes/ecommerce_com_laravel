<?php

namespace App\Models;


class pedido extends RModel
{
    
}
