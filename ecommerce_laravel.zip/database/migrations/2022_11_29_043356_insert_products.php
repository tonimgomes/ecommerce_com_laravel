<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $cat->save();

        $prod1 = new \App\Models\produto(['nome' => 'Pudim', 'valor' => 10, 'foto' => 'images/epudim.jpg', 'descricao' => '', 'categoria_id' => $cat->id]);
        $prod1->save();

        $prod2 = new \App\Models\produto(['nome' => 'Banoffe', 'valor' => 50, 'foto' => 'images/ebanoffe.jpg', 'descricao' => '', 'categoria_id' => $cat->id]);
        $prod2->save();

        $prod3 = new \App\Models\produto(['nome' => 'Brownie', 'valor' => 7, 'foto' => 'images/ebrownie.jpg', 'descricao' => '', 'categoria_id' => $cat->id]);
        $prod3->save();

        $prod4 = new \App\Models\produto(['nome' => 'Palha', 'valor' => 7, 'foto' => 'images/epalha.jpeg', 'descricao' => '', 'categoria_id' => $cat->id]);
        $prod4->save();
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
};
