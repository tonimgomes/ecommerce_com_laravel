<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doces do Sonho</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.1/css/fontawesome.min.css" integrity="sha384-QYIZto+st3yW+o8+5OHfT6S482Zsvz2WfOzpFSXMF9zqeLcFV0/wlZpMtyFcZALm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <nav class = "navbar navbar-light navbar-expand-md bg-light pl-5 pr-5 mb-5">
        <a href="#" class = "navbar-brand">Doces dos Sonhos</a>
        <div class = "collapse navbar-collapse">
            <div class="navbar-nav">
                <a class="nav-link" href="{{route('home')}}">HOME</a>
                <a class="nav-link" href="{{route('cadastrar')}}">CADASTRAR</a>
            </div>
        </div>
        
        <a class="btn" href="{{route('ver_carrinho')}}"><i class="fa fa-cart-shopping"></i></i></a>
    </nav>

    <div>
            @yield("conteudo")
        
    </div>

</body>
</html>