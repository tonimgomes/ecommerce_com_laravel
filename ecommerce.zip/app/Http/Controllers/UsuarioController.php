<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;

class UsuarioController extends Controller
{
    public function login(Request $request){
        $data = [];
        
        if($request->isMethod("POST")){
           $login = $request->input("login"); 
           $senha = $request->input("senha"); 

           $credential = ['login' => $login, 'password' => $senha];
           if(Auth::attempt($credential)){
                return redirect()->route("home");
           }else{
                $request->session()->flash("erro", "Usuario / senha incorreto");
                return redirect()->route("login");
           }
        }

        return view("login", $data);
    }

    public function logout(Request $request){
        Auth::logout();
        return redirect()->route("home");
    }
}
