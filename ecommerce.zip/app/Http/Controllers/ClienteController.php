<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\usuario;
use App\Models\endereco;
use App\Services\ClienteService;
class ClienteController extends Controller
{
    public function cadastrar(Request $request){
        $data = [];
        return view("cadastrar", $data);
    }

    public function cadastrarCliente(Request $request){
        
        $values = $request->all();
        $usuario = new usuario();
        $usuario->fill($values);
        
        $senha = $request->input("senha", "usuario");
        $usuario -> senha = \Hash::make($senha);

        $endereco = new endereco();
        $endereco->fill($values);
        
        $clienteService = new ClienteService();
        $resultado = $clienteService -> salvarUsuario($usuario, $endereco);
        
        $message = $resultado["message"];
        $status = $resultado["status"];

        $request->session()->flash($status, $message);
        
        return redirect()->route("cadastrar");
    }
}
