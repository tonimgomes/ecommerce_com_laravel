<?php

namespace App\Services;
use Log;
use App\Models\usuario;
use App\Models\pedido;
use App\Models\itensPedido;

class VendaService{
    public function finalizarVenda($prods = [], usuario $user){
        try{
            \DB::beginTransaction();
            $hoje = new \DateTime();
            $pedido = new pedido();
            $pedido -> data_pedido = $hoje->format("Y-m-d H:i:s");
            $pedido -> status = "Pendente";
            $pedido -> usuario_id = $user->id;
            $pedido -> save();

            foreach($prods as $p){
                $itens = new itensPedido();
                $itens -> quantidade = 1;
                $itens -> valor = $p -> valor;
                $itens -> data_item = $hoje->format("Y-m-d H:i:s");
                $itens -> produto_id = $p->id;
                $itens -> pedido_id =  $pedido->id;
                $itens ->save();
            }
            \DB::commit();
            return ['status' => 'ok', 'message' => 'Compra Finzalizada'];
        }catch(\Exception $e){
            \DB::rollback();
            Log::error("ERRO:VENDA SERVICE", ['message' => $e->getMessage()]);
            return ['status' => 'erro', 'message' => 'Ocorreu um erro ao finalizar a compra'];
        }
    }
}