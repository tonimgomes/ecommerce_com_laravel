<?php

namespace App\Services;

use Illuminate\Http\Request;
use App\Models\usuario;
use App\Models\endereco;
use Log;

class ClienteService{
    
    public function salvarUsuario(usuario $usuario, endereco $endereco ){
        try{
            $dbUsuario = usuario::where("login", $usuario -> login)->first();
            if($dbUsuario){
                return ['status' => 'erro', 'message' => 'Email ja cadastrado'];
            }
            \DB::beginTransaction();
            $usuario -> save();
            $endereco -> usuario_id = $usuario->id;
            $endereco -> save();
            \DB::commit();
            return ['status' => 'ok', 'message' => 'Usuario cadastrado'];
        }catch(\Exception $e){
            \Log::error("ERRO", ['file' => 'ClienteService.salvarUsuario','message' => $e->getMessage()]);
            \DB::rollback();
            return ['status' => 'erro', 'message' => 'Erro ao cadastrar o usuario'];
        }
    }

}

