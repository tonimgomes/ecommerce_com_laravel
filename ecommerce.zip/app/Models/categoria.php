<?php

namespace App\Models;

class categoria extends RModel
{
   protected $table = "categorias";
   protected $fillable = ['categoria'];
}
