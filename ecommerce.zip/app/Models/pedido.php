<?php

namespace App\Models;


class pedido extends RModel
{
    protected $table = "pedidos";
    protected $dates = ["data_pedido"];
    protected $fillable = ['data_pedido','status','usuario_id'];

}
