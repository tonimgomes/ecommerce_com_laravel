<?php

namespace App\Models;

class endereco extends RModel
{
    protected $table = "enderecos";
    protected $fillable = ['rua','numero','complemento','cep', 'estado'];

}
