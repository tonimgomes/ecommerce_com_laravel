<?php

namespace App\Models;


class itensPedido extends RModel
{
    protected $table = "itens_pedidos";
    protected $fillable = ['data_item','quantidade','valor', 'produto_id', 'pedido_id'];

}
