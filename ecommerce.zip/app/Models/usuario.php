<?php

namespace App\Models;

use Illuminate\Contracts\Auth\Authenticatable;

class usuario extends RModel implements Authenticatable
{
    protected $table = "usuarios";
    protected $fillable = ['nome','login','senha'];

    public function getAuthIdentifierName(){ 
        return 'login';
    }
    
    public function getAuthIdentifier(){
        return $this->login;
    }
    public function getAuthPassword(){
        return $this->senha;
    }
  
    public function getRememberToken(){

    }
    public function setRememberToken($value){

    }
    public function getRememberTokenName(){

    }
}
