@extends("layout")
@section("scriptjs")
<script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js" integrity="sha512-pHVGpX7F/27yZ0ISY+VVjyULApbDlD0/X0rgGbTqCE7WFW5MezNTWG/dnhtbBuICzsd0WQPgpE4REBLv+UqChw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
    $(function(){
        $("#cep").mask("00.000-000")
    })
</script>
@endsection
@section("conteudo")
<div class="col-10">
    <div class="col-10">
        <h2>Cadastrar Cliente</h2>
    </div>
    <form action = "{{route('cadastrar_cliente')}}" method = "post">
        @csrf
        <div class = "row">
            <div class="col-10">
                <div class = "form-group">
                Nome: <input type = "text" name = "nome" class = "form-control" />
                </div>
            </div>

            <div class="col-6">
                <div class = "form-group">
                E-mail: <input type = "email" name = "login" class = "form-control" />
                </div>
            </div>

            <div class="col-4">
                <div class = "form-group">
                Senha: <input type = "password" name = "senha" class = "form-control" />
                </div>
            </div>

            <div class="col-6">
                <div class = "form-group">
                Endereço: <input type = "text" name = "rua" class = "form-control" />
                </div>
            </div>

            <div class="col-1">
                <div class = "form-group">
                Numero: <input type = "text" name = "numero" class = "form-control" />
                </div>
            </div>

            <div class="col-3">
                <div class = "form-group">
                Complemento: <input type = "text" name = "complemento" class = "form-control" />
                </div>
            </div>

            <div class="col-4">
                <div class = "form-group">
                Cidade: <input type = "text" name = "cidade" class = "form-control" />
                </div>
            </div>

            <div class="col-2">
                <div class = "form-group">
                CEP: <input type = "text" name = "cep" id="cep" class = "form-control" />
                </div>
            </div>

            <div class="col-4">
                <div class = "form-group">
                Estado: <input type = "text" name = "estado" class = "form-control" />
                </div>
            </div>
        </div>
        <input type="submit" value = "Cadastrar" class = "btn btn-success btn-sm mt-2" />
    </form>
</div>
@endsection