
<?php $__env->startSection("conteudo"); ?>
    <div class = "col-12">
        <h2 class = "mb-3">Login no Sistema</h2>
        
        <form action = "<?php echo e(route('login')); ?>" method = "post">
            <?php echo csrf_field(); ?>
            <div class = "form-group">
                Email: 
                <input type = "text" name = "login" class = "form-control" />
            </div>

            <div class = "form-group">
                Senha: 
                <input type = "password" name = "senha" class = "form-control" />
            </div>

            <input type = "submit" value = "logar" class="btn btn-lg btn-primary mt-3">
        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anton\ecommerce\resources\views/login.blade.php ENDPATH**/ ?>