
<?php $__env->startSection("scriptjs"); ?>
<script>
    $(function(){
        $(".infocompra").on('click', function(){
            let id = $(this).attr("data-value")
            $.post('<?php echo e(route("compra_detalhes")); ?>', {idpedido: id}, (result)=>{
                $("#conteudopedido").html(result)
            })
        })
    })
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("conteudo"); ?>

    <div class = "col-12">
        <h2>Minhas compras</h2>
    </div>

    <div class = "col-12">
        <table class = "table table-bordered">
            <tr>
                <th>Data da Compra</th>
                <th>Situação</th>
            </tr>
        <?php $__currentLoopData = $lista; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ped): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($ped -> data_pedido->format("d/m/Y H:i")); ?></td>
                <td><?php echo e($ped -> status); ?></td>
                <td>
                    <a href = "#" class = "btn btn-sm btn-info infocompra" data-value="<?php echo e($ped -> id); ?>" data-toggle ="modal" data-target = "#modalcompra">
                        <i class = "fa fa-shopping-basket"></i>
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>

    <div class = "modal fade" id="modalcompra">
        <div class = "modal-dialog">
            <div class = "modal-content">
                <div class = "modal-header">
                    <h5 class = "modal-title">Detalhes da Compra</h5>
                </div>
                <div class = "modal-body">
                    <div id = "conteudopedido"></div>
                </div>
                <div class = "modal-footer">
                    <button type="button" class = "btn btn-sm btn-secondary" data-dismiss = "modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make("layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anton\ecommerce\resources\views/compra/historico.blade.php ENDPATH**/ ?>